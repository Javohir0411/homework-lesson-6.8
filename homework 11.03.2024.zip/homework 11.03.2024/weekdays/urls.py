from django.urls import path
from .views import index, uz_week, rus_week, en_week, weekdays

urlpatterns = [
    path('', index, name='index'),
    path('weekdays/', weekdays, name='weekdays'),
    path('uz/', uz_week, name='uz_week'),
    path('en/', en_week, name='en_week'),
    path('ru/', rus_week, name='rus_week')
]
