from django.http import HttpResponse
from django.shortcuts import render


def index(request):
    with open('templates/index.html', 'r') as f:
        html_file = f.read()
        return HttpResponse(html_file)


def uz_week(request):
    with open('templates/uz_week.html', 'r') as f:
        html_obj = f.read()
        return HttpResponse(html_obj)


def rus_week(request):
    with open('templates/rus_week.html', 'rb') as f:
        html_object = f.read()
        return HttpResponse(html_object)


def en_week(request):
    with open('templates/en_week.html', 'r') as f:
        html_f = f.read()
        return HttpResponse(html_f)


def weekdays(request):
    with open('templates/weekdays.html', 'rb') as f:
        html_content = f.read()
        return HttpResponse(html_content)
